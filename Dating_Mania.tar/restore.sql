--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.18 (Homebrew)
-- Dumped by pg_dump version 17.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "Dating_Mania";
--
-- Name: Dating_Mania; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "Dating_Mania" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'C';


ALTER DATABASE "Dating_Mania" OWNER TO postgres;

\connect "Dating_Mania"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: piyushthummar
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO piyushthummar;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: auth; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth (
    email character varying(255),
    password character varying(255),
    user_id integer
);


ALTER TABLE public.auth OWNER TO postgres;

--
-- Name: block; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.block (
    user_id integer NOT NULL,
    blocked_user_id integer NOT NULL,
    blocked_at timestamp without time zone DEFAULT now(),
    is_deleted boolean DEFAULT false
);


ALTER TABLE public.block OWNER TO postgres;

--
-- Name: hobbies; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.hobbies (
    hobby_id integer NOT NULL,
    hobby_name character varying(50) NOT NULL
);


ALTER TABLE public.hobbies OWNER TO postgres;

--
-- Name: hobbies_hobby_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.hobbies_hobby_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.hobbies_hobby_id_seq OWNER TO postgres;

--
-- Name: hobbies_hobby_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.hobbies_hobby_id_seq OWNED BY public.hobbies.hobby_id;


--
-- Name: matches; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.matches (
    sender_user_id integer NOT NULL,
    receiver_user_id integer NOT NULL,
    is_accepted boolean,
    accepted_at timestamp without time zone,
    sent_at timestamp without time zone DEFAULT now(),
    matched_on character varying(10),
    is_deleted boolean DEFAULT false,
    CONSTRAINT matches_matched_on_check CHECK (((matched_on)::text = ANY ((ARRAY['song'::character varying, 'hobby'::character varying, 'humour'::character varying])::text[])))
);


ALTER TABLE public.matches OWNER TO postgres;

--
-- Name: song_types; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.song_types (
    type_id integer NOT NULL,
    type_name character varying(20) NOT NULL
);


ALTER TABLE public.song_types OWNER TO postgres;

--
-- Name: song_types_type_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.song_types_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.song_types_type_id_seq OWNER TO postgres;

--
-- Name: song_types_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.song_types_type_id_seq OWNED BY public.song_types.type_id;


--
-- Name: songs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.songs (
    song_id integer NOT NULL,
    song_name character varying(30) NOT NULL,
    song_url character varying(500),
    artist_name character varying(30) NOT NULL,
    type_id integer
);


ALTER TABLE public.songs OWNER TO postgres;

--
-- Name: songs_sid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.songs_sid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.songs_sid_seq OWNER TO postgres;

--
-- Name: songs_sid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.songs_sid_seq OWNED BY public.songs.song_id;


--
-- Name: user_hobbies; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_hobbies (
    user_id integer NOT NULL,
    hobby_id integer NOT NULL
);


ALTER TABLE public.user_hobbies OWNER TO postgres;

--
-- Name: user_song; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_song (
    user_id integer NOT NULL,
    song_id integer NOT NULL
);


ALTER TABLE public.user_song OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    user_id integer NOT NULL,
    name character varying(40) NOT NULL,
    bio text,
    gender character varying(1),
    age integer,
    phone character varying(10),
    email character varying(255) NOT NULL,
    city character varying(20),
    is_active boolean DEFAULT true,
    last_active timestamp without time zone DEFAULT now(),
    is_deleted boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    CONSTRAINT users_age_check CHECK (((age >= 18) AND (age <= 100))),
    CONSTRAINT users_gender_check CHECK (((gender)::text = ANY ((ARRAY['m'::character varying, 'f'::character varying])::text[])))
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_uid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_uid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_uid_seq OWNER TO postgres;

--
-- Name: users_uid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_uid_seq OWNED BY public.users.user_id;


--
-- Name: hobbies hobby_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hobbies ALTER COLUMN hobby_id SET DEFAULT nextval('public.hobbies_hobby_id_seq'::regclass);


--
-- Name: song_types type_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.song_types ALTER COLUMN type_id SET DEFAULT nextval('public.song_types_type_id_seq'::regclass);


--
-- Name: songs song_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.songs ALTER COLUMN song_id SET DEFAULT nextval('public.songs_sid_seq'::regclass);


--
-- Name: users user_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN user_id SET DEFAULT nextval('public.users_uid_seq'::regclass);


--
-- Data for Name: auth; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth (email, password, user_id) FROM stdin;
\.
COPY public.auth (email, password, user_id) FROM '$$PATH$$/3869.dat';

--
-- Data for Name: block; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.block (user_id, blocked_user_id, blocked_at, is_deleted) FROM stdin;
\.
COPY public.block (user_id, blocked_user_id, blocked_at, is_deleted) FROM '$$PATH$$/3868.dat';

--
-- Data for Name: hobbies; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.hobbies (hobby_id, hobby_name) FROM stdin;
\.
COPY public.hobbies (hobby_id, hobby_name) FROM '$$PATH$$/3864.dat';

--
-- Data for Name: matches; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.matches (sender_user_id, receiver_user_id, is_accepted, accepted_at, sent_at, matched_on, is_deleted) FROM stdin;
\.
COPY public.matches (sender_user_id, receiver_user_id, is_accepted, accepted_at, sent_at, matched_on, is_deleted) FROM '$$PATH$$/3865.dat';

--
-- Data for Name: song_types; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.song_types (type_id, type_name) FROM stdin;
\.
COPY public.song_types (type_id, type_name) FROM '$$PATH$$/3860.dat';

--
-- Data for Name: songs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.songs (song_id, song_name, song_url, artist_name, type_id) FROM stdin;
\.
COPY public.songs (song_id, song_name, song_url, artist_name, type_id) FROM '$$PATH$$/3862.dat';

--
-- Data for Name: user_hobbies; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_hobbies (user_id, hobby_id) FROM stdin;
\.
COPY public.user_hobbies (user_id, hobby_id) FROM '$$PATH$$/3867.dat';

--
-- Data for Name: user_song; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_song (user_id, song_id) FROM stdin;
\.
COPY public.user_song (user_id, song_id) FROM '$$PATH$$/3866.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (user_id, name, bio, gender, age, phone, email, city, is_active, last_active, is_deleted, created_at, updated_at) FROM stdin;
\.
COPY public.users (user_id, name, bio, gender, age, phone, email, city, is_active, last_active, is_deleted, created_at, updated_at) FROM '$$PATH$$/3858.dat';

--
-- Name: hobbies_hobby_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.hobbies_hobby_id_seq', 20, true);


--
-- Name: song_types_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.song_types_type_id_seq', 10, true);


--
-- Name: songs_sid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.songs_sid_seq', 30, true);


--
-- Name: users_uid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_uid_seq', 35, true);


--
-- Name: block block_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.block
    ADD CONSTRAINT block_pkey PRIMARY KEY (user_id, blocked_user_id);


--
-- Name: hobbies hobbies_hobby_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hobbies
    ADD CONSTRAINT hobbies_hobby_name_key UNIQUE (hobby_name);


--
-- Name: hobbies hobbies_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hobbies
    ADD CONSTRAINT hobbies_pkey PRIMARY KEY (hobby_id);


--
-- Name: matches matches_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.matches
    ADD CONSTRAINT matches_pkey PRIMARY KEY (sender_user_id, receiver_user_id);


--
-- Name: song_types song_types_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.song_types
    ADD CONSTRAINT song_types_pkey PRIMARY KEY (type_id);


--
-- Name: song_types song_types_type_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.song_types
    ADD CONSTRAINT song_types_type_name_key UNIQUE (type_name);


--
-- Name: songs songs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.songs
    ADD CONSTRAINT songs_pkey PRIMARY KEY (song_id);


--
-- Name: user_hobbies user_hobbies_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_hobbies
    ADD CONSTRAINT user_hobbies_pkey PRIMARY KEY (user_id, hobby_id);


--
-- Name: user_song user_song_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_song
    ADD CONSTRAINT user_song_pkey PRIMARY KEY (user_id, song_id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- Name: auth auth_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth
    ADD CONSTRAINT auth_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id);


--
-- Name: block block_blocked_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.block
    ADD CONSTRAINT block_blocked_user_id_fkey FOREIGN KEY (blocked_user_id) REFERENCES public.users(user_id);


--
-- Name: block block_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.block
    ADD CONSTRAINT block_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id);


--
-- Name: matches matches_receiver_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.matches
    ADD CONSTRAINT matches_receiver_user_id_fkey FOREIGN KEY (receiver_user_id) REFERENCES public.users(user_id);


--
-- Name: matches matches_sender_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.matches
    ADD CONSTRAINT matches_sender_user_id_fkey FOREIGN KEY (sender_user_id) REFERENCES public.users(user_id);


--
-- Name: songs songs_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.songs
    ADD CONSTRAINT songs_type_id_fkey FOREIGN KEY (type_id) REFERENCES public.song_types(type_id);


--
-- Name: user_hobbies user_hobbies_hobby_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_hobbies
    ADD CONSTRAINT user_hobbies_hobby_id_fkey FOREIGN KEY (hobby_id) REFERENCES public.hobbies(hobby_id);


--
-- Name: user_hobbies user_hobbies_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_hobbies
    ADD CONSTRAINT user_hobbies_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id);


--
-- Name: user_song user_song_song_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_song
    ADD CONSTRAINT user_song_song_id_fkey FOREIGN KEY (song_id) REFERENCES public.songs(song_id);


--
-- Name: user_song user_song_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_song
    ADD CONSTRAINT user_song_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: piyushthummar
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

